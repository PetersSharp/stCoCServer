jquery.min.js
jquery.localize.min.js
tether.min.js
bootstrap.min.js
jquery.jvectormap.min.js
jquery.dataTables.min.js
dataTables.bootstrap4.min.js
bootstrap-datepicker.min.js
cocserver.js

