﻿
 Directory update source Geo data to Access stGeoFilter from MaxMind CSV (http://maxmind.com/)

 Download the latest location data from http://dev.maxmind.com/geoip/legacy/geolite/
 You will need "GeoIPCountryCSV.zip" and "GeoIPASNum2.zip" (the ZIP CSV variant).
 The ZIP file contains the two CSV files you will need for the import.
 If first line is copyright, you will need to remove the first line from each, which is copyright text and is invalid in a CSV file. 

